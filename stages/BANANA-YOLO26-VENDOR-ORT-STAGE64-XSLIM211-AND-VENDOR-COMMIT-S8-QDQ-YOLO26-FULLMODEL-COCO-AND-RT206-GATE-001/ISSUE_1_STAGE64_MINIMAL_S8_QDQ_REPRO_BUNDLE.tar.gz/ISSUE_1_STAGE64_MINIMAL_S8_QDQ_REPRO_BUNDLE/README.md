# Stage64 signed-INT8 QDQ minimal controls

This public-safe bundle contains only tiny generated ONNX graphs, synthetic
inputs, independent expected outputs, and a neutral ONNX Runtime runner. It
contains no YOLO model, trained weights, calibration or COCO data, camera
media, custom-executor source, vendor binary, credential, or private path.

## Cases

- `c1`, `c2`, `c5`: signed-INT8 QDQ Conv controls with explicit
  `kernel_shape`, including zero/nonzero activation zero points and
  per-channel/per-tensor weights.
- `c3`: signed-INT8 QDQ Conv without `kernel_shape`; exact CPU fallback is the
  placement control.
- `c4`: UINT8 QDQ Conv negative control.
- `m1`, `m2`: signed-INT8 QDQ MatMul controls with zero/nonzero activation
  zero points.
- `m3`: UINT8 QDQ MatMul negative control.
- `reducemax*`: XSlim 2.1.1 versus vendor-reference parser controls.

The files under `expected/` come from an independent local NumPy/operator
oracle, not from SpacemiT EP output.

## Build the neutral runner

Set `CXX` to the RISC-V compiler and `ORT_ROOT` to the extracted official
SpacemiT ORT 2.0.6 package:

```bash
"${CXX}" -std=c++17 -O2 -DNDEBUG -march=rv64gc -mabi=lp64d \
  -I"${ORT_ROOT}/include" \
  runner/stage64_single_model_runner.cpp \
  -L"${ORT_ROOT}/lib" -lspacemit_ep -lonnxruntime -ldl -pthread \
  -Wl,--no-undefined -o stage64_single_model_runner
```

Run CPU and provider arms independently:

```bash
LD_LIBRARY_PATH="${ORT_ROOT}/lib" taskset -c 0 timeout 90s \
  ./stage64_single_model_runner \
    --provider spacemit \
    --model models/c1_s8_conv_pc_explicit.onnx \
    --input inputs/c1_s8_conv_pc_explicit.input.bin \
    --output c1.output.bin

cmp c1.output.bin expected/c1_s8_conv_pc_explicit.oracle.bin
```

Use a process boundary and capture exit status/signal for negative controls.
The Stage64 evidence records that signed controls execute exactly, omitted
`kernel_shape` falls back to CPU, and UINT8 controls report unsupported
quantization before terminating with SIGABRT.

The bundle is evidence only. It does not promote a runtime or make a
production claim.
